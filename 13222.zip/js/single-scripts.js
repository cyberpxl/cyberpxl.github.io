var doughnutData = [
	{
		value: 70,
		color:"#74cfae"
	},
	{
		value : 30,
		color : "#3c3c3c"
	}
];
var myDoughnut = new Chart(document.getElementById("javascript").getContext("2d")).Doughnut(doughnutData);

var doughnutData = [
	{
		value: 90,
		color:"#74cfae"
	},
	{
		value : 10,
		color : "#3c3c3c"
	}
];
var myDoughnut = new Chart(document.getElementById("bootstrap").getContext("2d")).Doughnut(doughnutData);
var doughnutData = [
	{
		value: 65,
		color:"#74cfae"
	},
	{
		value : 35,
		color : "#3c3c3c"
	}
];
var myDoughnut = new Chart(document.getElementById("wordpress").getContext("2d")).Doughnut(doughnutData);
var doughnutData = [
	{
		value: 50,
		color:"#74cfae"
	},
	{
		value : 50,
		color : "#3c3c3c"
	}
];
var myDoughnut = new Chart(document.getElementById("photoshop").getContext("2d")).Doughnut(doughnutData);